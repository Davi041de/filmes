let age = 0; // Armazena a idade
let message = "Digite sua idade para recomendação de filmes:"; // Mensagem inicial
let input, button; // Elementos de entrada

function setup() {
  createCanvas(400, 200); // Define o tamanho da tela

  // Caixa de entrada para idade
  input = createInput();
  input.position(20, 60);

  // Botão para confirmar a entrada
  button = createButton('Confirmar');
  button.position(input.x + input.width + 10, 60);
  button.mousePressed(recommendMovie); // Ação ao clicar no botão

  // Configuração de texto inicial
  textAlign(CENTER);
  textSize(16);
}

function draw() {
  background(220); // Fundo da tela

  // Exibe a mensagem no topo
  fill(0);
  text(message, width / 2, 30);
}

function recommendMovie() {
  // Captura o valor da idade
  age = int(input.value());

  // Verifica a faixa etária e atribui a recomendação correspondente
  if (age < 6) {
    message = 'Recomendado: "Paddington" ou "A Viagem de Chihiro"';
  } else if (age < 10) {
    message = 'Recomendado: "As Aventuras de Pi"';
  } else if (age < 12) {
    message = 'Recomendado: "Depois da Chuva"';
  } else if (age < 14) {
    message = 'Recomendado: "Guardiões da Galáxia" ou "Ladrões de Bicicleta"';
  } else if (age < 16) {
    message = 'Recomendado: "O Menino Que Descobriu o Vento" ou "O Silêncio dos Inocentes"';
  } else if (age < 18) {
    message = 'Recomendado: "Django Livre"';
  } else {
    message = 'Recomendado: "A Substância"';
  }

  // Limpa o campo de entrada
  input.value('');
}