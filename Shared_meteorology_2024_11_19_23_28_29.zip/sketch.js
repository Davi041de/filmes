// fantasia, aventura, drama, misterio, suspense, terror

// a viagem de chihiro, LIVRE, fantasia, aventura
// paddington, LIVRE, fantasia, aventura
// as aventuras de pi, 10, drama, fantasia, aventura
// depois da chuva, 10, drama
// guardiões da galáxia, 12, fantasia, aventura
// ladrões de bicicleta, 12, drama
// o menino que descobriu o vento, 14, drama
// O Silêncio dos Inocentes, 14, drama, misterio, suspense
//Django Livre, 16, drama
//A Substância, 18, drama, terror

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}